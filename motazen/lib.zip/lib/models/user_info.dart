class UserInfo {
  String firstname;
  String avatar;
  String id;
  double currentCommunityProgress;

  UserInfo(this.id, this.avatar, this.firstname, this.currentCommunityProgress);
}
