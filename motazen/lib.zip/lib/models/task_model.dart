class TaskData {
  late List<String> taskDependency = [];
  late String name = "";
}
